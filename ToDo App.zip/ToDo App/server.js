const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

const filePath = path.join(__dirname, 'data', 'tasks.json');

app.use(express.json());

// Serve static files from the public folder
app.use(express.static(path.join(__dirname, 'public')));

// API: Get all tasks
app.get('/tasks', (req, res) => {
  const raw = fs.readFileSync(filePath, 'utf8') || '[]';
  const tasks = JSON.parse(raw);
  res.json(tasks);
});

// API: Add a new task
app.post('/tasks', (req, res) => {
  const raw = fs.readFileSync(filePath, 'utf8') || '[]';
  const tasks = JSON.parse(raw);
  const newTask = {
    id: Date.now().toString(),
    title: req.body.title
  };
  tasks.push(newTask);
  fs.writeFileSync(filePath, JSON.stringify(tasks, null, 2));
  res.status(201).json(newTask);
});

// API: Delete a task
app.delete('/tasks/:id', (req, res) => {
  const raw = fs.readFileSync(filePath, 'utf8') || '[]';
  const tasks = JSON.parse(raw);
  const updated = tasks.filter(task => task.id !== req.params.id);
  fs.writeFileSync(filePath, JSON.stringify(updated, null, 2));
  res.json({ message: 'Task deleted' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
