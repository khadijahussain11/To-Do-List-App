const read  = require('fs');
const { readTasks, writeTasks} = require('./utils/fileHandler');

const process = require('process');
// const { useOptimistic } = require('react');

const command = process.argv[2];
const input = process.argv[3];

if(command === 'add'){
    const tasks = readTasks();
    const newTask = {
        id: Date.now().toString(),
        title: input
    };
    tasks.push(newTask);
    writeTasks(tasks);
    console.log('Task added:', input);
}
else if(command === 'list'){
    const tasks = readTasks();
    console.log('Your Tasks:');
    tasks.forEach(task =>  console.log(`${task.id}: ${task.title}`)

    );
}

else if(command==='delete'){
    const tasks = readTasks();
    const updatedTasks = tasks.filter(task => task.id !== input);
    writeTasks(updatedTasks);
    console.log(`Task deleted with id: ${input}`);
}

else{
    console.log('command not recognized');
}